import { useEffect, useState } from "react";
import axiosInstance from "../axios/axios";

const Product = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await axiosInstance.get("/products");
        setProducts(res.data);
        console.log(res.data);
      } catch (error) {
        console.error;
      }
    };

    fetchProducts();
  }, []);
  return (
    <>
      <h1>Product List</h1>
      <ul>
        {products.map((product) => (
          <li
            key={product.id}
            style={{ marginBottom: "20px", listStyleType: "none" }}
          >
            <img
              src={product.image}
              alt={product.productName}
              style={{ width: "150px", height: "150px", objectFit: "cover" }}
            />
            <h2>{product.productName}</h2>
            <p>{product.description}</p>
            <p>Price: ${product.price.toFixed(2)}</p>
            <p>Category: {product.category}</p>
          </li>
        ))}
      </ul>
    </>
  );
};

export default Product;
