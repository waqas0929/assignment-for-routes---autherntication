import React from 'react';
import Product from './pages/Products';

const App = () => {
  return (
    <>
    <Product />
    </>
  );
}

export default App;
