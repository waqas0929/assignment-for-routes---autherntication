import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <div className="bg-gray-800">
      <nav className="container mx-auto flex items-center justify-between p-4">
        <ul className="flex space-x-4">
          <li>
            <Link to="/" className="text-white hover:text-gray-400">
              Home
            </Link>
          </li>
          <li>
            <Link to="/signup" className="text-white hover:text-gray-400">
              Signup
            </Link>
          </li>
          <li>
            <Link to="/login" className="text-white hover:text-gray-400">
              Login
            </Link>
          </li>
          <li>
            <Link to="/product" className="text-white hover:text-gray-400">
              Product
            </Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Navbar;
